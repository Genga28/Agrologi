// PackagingStandards.js
import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, ScrollView } from 'react-native';

const PackagingStandards = () => {
  const [standardID, setStandardID] = useState('');
  const [standardInfo, setStandardInfo] = useState('');

  const handleFetchStandards = async () => {
    try {
      const response = await fetch('https://your-api-endpoint.com/packaging-standards', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ standardID }),
      });
      const result = await response.json();
      setStandardInfo(result.standardInfo);
    } catch (error) {
      console.error('Error fetching packaging standards:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Packaging Standards</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Standard ID"
          value={standardID}
          onChangeText={setStandardID}
        />
        <Button title="Fetch Standards" onPress={handleFetchStandards} />
        {standardInfo && (
          <View style={styles.infoContainer}>
            <Text style={styles.infoText}>{standardInfo}</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    elevation: 3,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 4,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  infoContainer: {
    marginTop: 16,
  },
  infoText: {
    fontSize: 16,
  },
});

export default PackagingStandards;
