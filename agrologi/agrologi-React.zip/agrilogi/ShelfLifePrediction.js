// ShelfLifePrediction.js
import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, ScrollView } from 'react-native';

const ShelfLifePrediction = () => {
  const [features, setFeatures] = useState('');
  const [prediction, setPrediction] = useState('');

  const handlePredictShelfLife = async () => {
    try {
      const response = await fetch('https://your-api-endpoint.com/predict-shelf-life', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ features }),
      });
      const result = await response.json();
      setPrediction(result.predictedShelfLife);
    } catch (error) {
      console.error('Error predicting shelf life:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Shelf Life Prediction</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter features for prediction"
          value={features}
          onChangeText={setFeatures}
        />
        <Button title="Predict Shelf Life" onPress={handlePredictShelfLife} />
        {prediction && (
          <View style={styles.predictionContainer}>
            <Text style={styles.predictionText}>Predicted Shelf Life: {prediction}</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    elevation: 3,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 4,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  predictionContainer: {
    marginTop: 16,
  },
  predictionText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ShelfLifePrediction;
