// Traceability.js
import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, ScrollView } from 'react-native';

const Traceability = () => {
  const [productID, setProductID] = useState('');
  const [traceabilityInfo, setTraceabilityInfo] = useState('');

  const handleFetchTraceability = async () => {
    try {
      const response = await fetch('https://your-api-endpoint.com/traceability', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ productID }),
      });
      const result = await response.json();
      setTraceabilityInfo(result.traceabilityInfo);
    } catch (error) {
      console.error('Error fetching traceability:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Traceability Information</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Product ID"
          value={productID}
          onChangeText={setProductID}
        />
        <Button title="Fetch Traceability" onPress={handleFetchTraceability} />
        {traceabilityInfo && (
          <View style={styles.infoContainer}>
            <Text style={styles.infoText}>{traceabilityInfo}</Text>
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    elevation: 3,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 4,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  infoContainer: {
    marginTop: 16,
  },
  infoText: {
    fontSize: 16,
  },
});

export default Traceability;
