import React, { useState } from 'react';
import { View, Text, Button, TextInput, StyleSheet } from 'react-native';

const InventoryManagement = () => {
  const [productID, setProductID] = useState('');
  const [quantity, setQuantity] = useState('');
  const [inventory, setInventory] = useState([]);

  const handleAddToInventory = () => {
    setInventory(prevInventory => [
      ...prevInventory,
      { productID, quantity: parseInt(quantity) }
    ]);
    console.log('Inventory:', inventory);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Inventory Management</Text>
      <TextInput
        style={styles.input}
        placeholder="Product ID"
        value={productID}
        onChangeText={setProductID}
      />
      <TextInput
        style={styles.input}
        placeholder="Quantity"
        value={quantity}
        onChangeText={setQuantity}
        keyboardType="numeric"
      />
      <Button title="Add to Inventory" onPress={handleAddToInventory} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 16,
    paddingHorizontal: 8,
  },
});

export default InventoryManagement;
