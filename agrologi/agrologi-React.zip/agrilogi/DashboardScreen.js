import React from 'react';
import { ScrollView, View, Text, Button, StyleSheet } from 'react-native';

const DashboardScreen = ({ onLogout }) => (
  <ScrollView contentContainerStyle={styles.container}>
    <Text style={styles.title}>Dashboard</Text>
    <Button title="Manage Inventory" onPress={() => { /* Navigate to Inventory Management */ }} />
    <Button title="Temperature Control" onPress={() => { /* Navigate to Temperature Control */ }} />
    <Button title="Shelf Life Prediction" onPress={() => { /* Navigate to Shelf Life Prediction */ }} />
    <Button title="Traceability" onPress={() => { /* Navigate to Traceability */ }} />
    <Button title="Packaging Standards" onPress={() => { /* Navigate to Packaging Standards */ }} />
    <Button title="Logout" onPress={onLogout} />
  </ScrollView>
);

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
});

export default DashboardScreen;
