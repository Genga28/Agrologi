import * as SQLite from 'expo-sqlite';

const db = SQLite.openDatabase('inventory.db');

// Function to initialize the database and create tables if they do not exist
export const initDB = () => {
  db.transaction(tx => {
    tx.executeSql(
      'CREATE TABLE IF NOT EXISTS inventory (id INTEGER PRIMARY KEY NOT NULL, productID TEXT NOT NULL, quantity INTEGER NOT NULL)',
      [],
      () => console.log('Table created successfully'),
      (_, error) => console.error('Table creation error:', error)
    );
  });
};

// Function to add an item to the inventory
export const addItemToInventory = (productID, quantity, callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT INTO inventory (productID, quantity) VALUES (?, ?)',
      [productID, quantity],
      (_, result) => callback(result),
      (_, error) => console.error('Insert error:', error)
    );
  });
};

// Function to fetch inventory items
export const fetchInventory = (callback) => {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM inventory',
      [],
      (_, result) => callback(result.rows._array),
      (_, error) => console.error('Fetch error:', error)
    );
  });
};
