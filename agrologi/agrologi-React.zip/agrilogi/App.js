import React, { useEffect, useState } from 'react';
import { ScrollView, StyleSheet } from 'react-native';
import LoginScreen from './LoginScreen';
import DashboardScreen from './DashboardScreen';
import InventoryManagement from './InventoryManagement';
import TemperatureControl from './TemperatureControl';
import ShelfLifePrediction from './ShelfLifePrediction';
import Traceability from './Traceability';
import PackagingStandards from './PackagingStandards';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = () => setIsLoggedIn(true);
  const handleLogout = () => setIsLoggedIn(false);

  if (!isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <DashboardScreen onLogout={handleLogout} />
      <InventoryManagement />
      <TemperatureControl />
      <ShelfLifePrediction />
      <Traceability />
      <PackagingStandards />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
});
