// TemperatureControl.js
import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet, ScrollView } from 'react-native';

const TemperatureControl = () => {
  const [zoneID, setZoneID] = useState('');
  const [temperature, setTemperature] = useState('');
  const [zoneTemperatures, setZoneTemperatures] = useState({});

  const handleSetTemperature = () => {
    setZoneTemperatures(prev => ({
      ...prev,
      [zoneID]: temperature,
    }));
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Temperature Control</Text>
        <TextInput
          style={styles.input}
          placeholder="Zone ID"
          value={zoneID}
          onChangeText={setZoneID}
        />
        <TextInput
          style={styles.input}
          placeholder="Temperature"
          value={temperature}
          onChangeText={setTemperature}
          keyboardType="numeric"
        />
        <Button title="Set Temperature" onPress={handleSetTemperature} />
        {Object.keys(zoneTemperatures).length > 0 && (
          <View style={styles.tempContainer}>
            <Text style={styles.tempTitle}>Current Temperatures:</Text>
            {Object.entries(zoneTemperatures).map(([zone, temp], index) => (
              <Text key={index} style={styles.tempText}>
                Zone {zone}: {temp}°C
              </Text>
            ))}
          </View>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginBottom: 16,
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    elevation: 3,
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  input: {
    height: 40,
    borderColor: '#ddd',
    borderWidth: 1,
    borderRadius: 4,
    marginBottom: 12,
    paddingHorizontal: 8,
  },
  tempContainer: {
    marginTop: 16,
  },
  tempTitle: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  tempText: {
    fontSize: 14,
    marginVertical: 4,
  },
});

export default TemperatureControl;
